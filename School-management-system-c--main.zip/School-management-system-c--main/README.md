# School-management-system-c-
a school management system using C# and SQL server it just a try not compilated 
